(function () {
	'use strict';

	var data = window.PENCISOLEDAD_DASHBOARD || {};
	var wpElement = window.wp && window.wp.element;
	var wpComponents = window.wp && window.wp.components ? window.wp.components : {};

	if ( ! wpElement ) {
		return;
	}

	var createElement = wpElement.createElement;
	var render = wpElement.render;
	var Fragment = wpElement.Fragment;
	var Button = wpComponents.Button;
	var Card = wpComponents.Card;
	var CardBody = wpComponents.CardBody;
	var Notice = wpComponents.Notice;
	var i18n = data.i18n || {};

	function el( tag, props ) {
		var children = Array.prototype.slice.call( arguments, 2 );
		return createElement.apply( null, [ tag, props ].concat( children ) );
	}

	function html( value ) {
		return {
			__html: value || '',
		};
	}

	function AppButton( props ) {
		var className = 'penci-dashboard-button';

		if ( props.isPrimary ) {
			className += ' is-primary';
		}

		if ( props.isDanger ) {
			className += ' is-danger';
		}

		var attrs = {
			className: className,
			href: props.href,
			target: props.target || undefined,
			rel: props.target ? 'noopener noreferrer' : undefined,
			onClick: props.onClick || undefined,
		};

		if ( Button ) {
			return createElement(
				Button,
				{
					href: props.href,
					className: className,
					variant: props.isPrimary ? 'primary' : 'secondary',
					target: props.target || undefined,
					rel: props.target ? 'noopener noreferrer' : undefined,
					onClick: props.onClick || undefined,
				},
				props.children
			);
		}

		return el( 'a', attrs, props.children );
	}

	function Panel( props ) {
		if ( Card && CardBody ) {
			return createElement(
				Card,
				{
					className: props.className,
				},
				createElement( CardBody, null, props.children )
			);
		}

		return el( 'section', { className: props.className }, props.children );
	}

	function SvgIcon( props ) {
		var paths = {
			plugins: [
				'M12 2.75l1.46 3.02 3.33.48-2.41 2.35.57 3.32L12 10.35 9.05 11.92l.57-3.32-2.41-2.35 3.33-.48L12 2.75z',
				'M6.5 13.25h11a2.25 2.25 0 012.25 2.25v2A2.25 2.25 0 0117.5 19.75h-11a2.25 2.25 0 01-2.25-2.25v-2a2.25 2.25 0 012.25-2.25z',
				'M8 16.5h.01M12 16.5h.01M16 16.5h.01',
			],
			layout: [
				'M4.75 5.75A2 2 0 016.75 3.75h10.5a2 2 0 012 2v12.5a2 2 0 01-2 2H6.75a2 2 0 01-2-2V5.75z',
				'M4.75 9.25h14.5M9.25 9.25v11',
			],
			customizer: [
				'M4.75 18.25l5.2-1.3 8.84-8.84a2.12 2.12 0 00-3-3l-8.84 8.84-1.3 5.2z',
				'M14.5 6.4l3.1 3.1M4.75 21.25h14.5',
			],
			document: [
				'M7.25 3.75h6.5l4 4v10.5a2 2 0 01-2 2h-8.5a2 2 0 01-2-2V5.75a2 2 0 012-2z',
				'M13.75 3.75v4h4M8.5 12.25h7M8.5 15.75h5',
			],
			video: [
				'M5.75 7.25h9.5a2 2 0 012 2v5.5a2 2 0 01-2 2h-9.5a2 2 0 01-2-2v-5.5a2 2 0 012-2z',
				'M17.25 10.25l3-1.75v7l-3-1.75v-3.5z',
			],
			license: [
				'M7.75 10.25v-2.5a4.25 4.25 0 018.5 0v2.5',
				'M6.25 10.25h11.5a1.5 1.5 0 011.5 1.5v7a1.5 1.5 0 01-1.5 1.5H6.25a1.5 1.5 0 01-1.5-1.5v-7a1.5 1.5 0 011.5-1.5z',
				'M12 14.25v2.5',
			],
		};

		return el(
			'span',
			{ className: 'penci-dashboard-card-icon', 'aria-hidden': 'true' },
			el(
				'svg',
				{
					viewBox: '0 0 24 24',
					fill: 'none',
					focusable: 'false',
				},
				(paths[ props.icon ] || paths.document).map( function ( path, index ) {
					return el( 'path', {
						key: index,
						d: path,
						stroke: 'currentColor',
						strokeWidth: 1.8,
						strokeLinecap: 'round',
						strokeLinejoin: 'round',
					} );
				} )
			)
		);
	}

	function Nav() {
		return el(
			'nav',
			{ className: 'penci-dashboard-nav', 'aria-label': data.themeName + ' admin navigation' },
			(data.nav || []).map( function ( item ) {
				return el(
					'a',
					{
						key: item.label,
						href: item.url,
						target: item.target || undefined,
						rel: item.target ? 'noopener noreferrer' : undefined,
						className: item.active ? 'is-active' : '',
						'aria-current': item.active ? 'page' : undefined,
					},
					item.label
				);
			} )
		);
	}

	function StatusTile( props ) {
		return el(
			'div',
			{ className: 'penci-dashboard-status-tile' },
			el( 'span', { className: 'penci-dashboard-status-label' }, props.label ),
			el( 'strong', null, props.value ),
			props.meta ? el( 'span', { className: 'penci-dashboard-status-meta' }, props.meta ) : null
		);
	}

	function Hero() {
		var props = arguments.length > 0 && arguments[0] ? arguments[0] : {};
		var actions = props.actions || [
			{ href: data.urls.documentation, target: '_blank', isPrimary: true, label: i18n.viewDocumentation },
			{ href: data.urls.customizer, label: i18n.startCustomize },
		];
		var statusTiles = props.statusTiles || [
			{
				label: i18n.status,
				value: data.isActivated ? i18n.activated : i18n.notActivated,
				meta: data.hasLicense ? i18n.license : '',
			},
			{
				label: i18n.version,
				value: data.themeVersion,
				meta: data.isChild && data.parentVersion ? 'Parent ' + data.parentVersion : '',
			},
			{
				label: i18n.updateAvailable,
				value: data.hasUpdate ? data.updateVersion : i18n.upToDate,
				meta: data.hasUpdate ? i18n.updateAvailable : '',
			},
		];
		var aboutHtml = props.hasOwnProperty( 'aboutHtml' ) ? props.aboutHtml : data.aboutHtml;
		var customWelcomeHtml = props.hasOwnProperty( 'customWelcomeHtml' ) ? props.customWelcomeHtml : data.customWelcomeHtml;

		return el(
			'header',
			{ className: 'penci-dashboard-hero' },
			el(
				'div',
				{ className: 'penci-dashboard-hero-content' },
				el( 'p', { className: 'penci-dashboard-kicker' }, data.themeName ),
				el( 'h1', null, props.title || data.title ),
				(props.subtitle || data.subtitle) ? el( 'p', { className: 'penci-dashboard-subtitle' }, props.subtitle || data.subtitle ) : null,
				aboutHtml ? el( 'div', { className: 'penci-dashboard-about', dangerouslySetInnerHTML: html( aboutHtml ) } ) : null,
				customWelcomeHtml ? el( 'div', { className: 'penci-dashboard-custom-welcome', dangerouslySetInnerHTML: html( customWelcomeHtml ) } ) : null,
				el(
					'div',
					{ className: 'penci-dashboard-hero-actions' },
					actions.map( function ( action ) {
						return el( AppButton, {
							key: action.label,
							href: action.href,
							target: action.target,
							isPrimary: action.isPrimary,
							isDanger: action.isDanger,
						}, action.label );
					} )
				)
			),
			el(
				'div',
				{ className: 'penci-dashboard-status-grid', 'aria-label': i18n.status },
				statusTiles.map( function ( tile ) {
					return el( StatusTile, {
						key: tile.label,
						label: tile.label,
						value: tile.value,
						meta: tile.meta,
					} );
				} )
			),
			data.showPenciBadge ? el(
				'a',
				{ className: 'penci-dashboard-badge', href: data.urls.penci, target: '_blank', rel: 'noopener noreferrer' },
				el( 'img', { src: data.badgeUrl, alt: 'PenciDesign' } )
			) : null
		);
	}

	function StepCard( props ) {
		return el(
			Panel,
			{ className: 'penci-dashboard-card penci-dashboard-step-card' },
			el(
				'div',
				{ className: 'penci-dashboard-card-heading' },
				el( 'span', { className: 'penci-dashboard-step-number' }, i18n.step + ' ' + props.number ),
				el( SvgIcon, { icon: props.icon } )
			),
			el( 'h3', null, props.title ),
			props.html ? el( 'p', { dangerouslySetInnerHTML: html( props.html ) } ) : el( 'p', null, props.description ),
			props.extra ? el( 'p', { className: 'penci-dashboard-muted' }, props.extra ) : null,
			props.sync ? el(
				'div',
				{ className: 'penci-dashboard-inline-notice' },
				el( 'p', null, i18n.syncDesc ),
				el( AppButton, { href: data.urls.sync, isPrimary: true }, i18n.syncCustomizer )
			) : null,
			el(
				'div',
				{ className: 'penci-dashboard-card-actions' },
				(props.actions || []).map( function ( action ) {
					return el( AppButton, {
						key: action.label,
						href: action.href,
						target: action.target,
						isPrimary: action.primary,
					}, action.label );
				} )
			)
		);
	}

	function ResourceCard( props ) {
		return el(
			Panel,
			{ className: 'penci-dashboard-card penci-dashboard-resource-card' },
			el( SvgIcon, { icon: props.icon } ),
			el( 'h3', null, props.title ),
			el( 'p', { dangerouslySetInnerHTML: html( props.html || props.description ) } ),
			el( AppButton, { href: props.href, target: props.target, isPrimary: props.primary }, props.button )
		);
	}

	function GettingStarted() {
		var steps = [
			{
				number: 1,
				icon: 'plugins',
				title: i18n.installTitle,
				description: i18n.pluginsDesc,
				extra: i18n.pluginsHelp,
				actions: [
					{ label: i18n.viewDocumentation, href: data.urls.documentation, target: '_blank' },
					{ label: i18n.installPlugins, href: data.urls.plugins, target: '_blank', primary: true },
				],
			},
			{
				number: 2,
				icon: 'layout',
				title: i18n.demoTitle,
				html: i18n.demoDescHtml,
				actions: [
					{ label: i18n.importDemo, href: data.urls.importDemo, target: '_blank', primary: true },
				],
			},
			{
				number: 3,
				icon: 'customizer',
				title: i18n.customizeTitle,
				html: i18n.customizeDescHtml,
				sync: !! data.urls.sync,
				actions: [
					{ label: i18n.startCustomize, href: data.urls.customizer, primary: true },
				],
			},
		];

		return el(
			Fragment,
			null,
			el( 'section', { className: 'penci-dashboard-section' },
				el( 'div', { className: 'penci-dashboard-section-heading' },
					el( 'h2', null, i18n.setupGuide ),
					el( 'p', null, i18n.quickActions )
				),
				el( 'div', { className: 'penci-dashboard-card-grid penci-dashboard-steps' }, steps.map( function ( step ) {
					return el( StepCard, Object.assign( { key: step.title }, step ) );
				} ) )
			),
			el( 'section', { className: 'penci-dashboard-section' },
				el( 'div', { className: 'penci-dashboard-section-heading' },
					el( 'h2', null, i18n.resources )
				),
				el( 'div', { className: 'penci-dashboard-card-grid' },
					el( ResourceCard, {
						icon: 'document',
						title: i18n.docsTitle,
						description: i18n.docsDesc,
						href: data.urls.documentation,
						target: '_blank',
						button: i18n.readDocumentation,
						primary: true,
					} ),
					el( ResourceCard, {
						icon: 'video',
						title: i18n.videosTitle,
						description: i18n.videosDesc,
						href: data.urls.videos,
						target: '_blank',
						button: i18n.viewVideos,
					} ),
					data.isActivated ? el( ResourceCard, {
						icon: 'license',
						title: i18n.licenseTitle,
						html: i18n.licenseDescHtml,
						href: data.urls.license,
						button: i18n.revokeLicense,
					} ) : null
				)
			)
		);
	}

	function ActivationPage() {
		var activation = data.activation || {};

		return el(
			Fragment,
			null,
			el( Hero, {
				title: i18n.activateSoledad,
				subtitle: i18n.activateSubtitle,
				aboutHtml: '',
				customWelcomeHtml: '',
				actions: [
					{ label: i18n.enterPurchaseCode, href: '#penci-check-license', isPrimary: true },
					{ label: i18n.findPurchaseCode, href: data.urls.purchaseCode, target: '_blank' },
				],
				statusTiles: [
					{ label: i18n.status, value: i18n.notActivated, meta: i18n.actionRequired },
					{ label: i18n.version, value: data.themeVersion },
					{ label: i18n.license, value: i18n.envatoPurchaseCode, meta: i18n.oneWebsiteLicense },
				],
			} ),
			el( Nav ),
			el(
				'section',
				{ className: 'penci-dashboard-section' },
				el(
					'div',
					{ className: 'penci-dashboard-section-heading' },
					el( 'h2', null, i18n.activation ),
					el( 'p', null, i18n.activationHelp )
				),
				el(
					'div',
					{ className: 'penci-license-layout' },
					el(
						Panel,
						{ className: 'penci-dashboard-card penci-license-main-card penci-activate-wrap gt-tab-pane gt-is-active' },
						el(
							'div',
							{ className: 'penci-activate-envato-code' },
							el( 'h3', { className: 'penci-activate-code-title' }, i18n.activateTheme ),
							el( 'p', { className: 'penci-activate-desc' }, activation.description ),
							el(
								'form',
								{ id: 'penci-check-license', action: data.urls.activation },
								el(
									'div',
									{ className: 'penci-activate-inputs' },
									el( 'input', {
										name: 'evato-code',
										className: 'penci-form-control evato-code',
										type: 'text',
										placeholder: i18n.purchaseCode,
										autoComplete: 'off',
									} ),
									el( 'input', {
										type: 'hidden',
										name: 'server-id',
										className: 'server-id',
										defaultValue: activation.serverId,
										readOnly: true,
									} ),
									el( 'span', { className: 'penci-form-control-bar' } ),
									el(
										'div',
										{ className: 'penci-activate-err' },
										el( 'span', { className: 'penci-err-missing' }, i18n.codeRequired ),
										el( 'span', { className: 'penci-err-length' }, i18n.codeTooShort ),
										el( 'span', { className: 'penci-err-invalid' }, i18n.codeInvalid )
									)
								),
								el( 'button', { className: 'soledad-activate-button penci-dashboard-button is-primary', type: 'submit' }, i18n.activateTheme ),
								el( 'div', { className: 'spinner' } ),
								el(
									'div',
									{ className: 'soledad-find-code' },
									el( 'a', { href: data.urls.purchaseCode, target: '_blank', rel: 'noopener noreferrer' }, i18n.findPurchaseCode )
								)
							)
						)
					),
					el(
						'div',
						{ className: 'penci-license-side' },
						el(
							Panel,
							{ className: 'penci-dashboard-card penci-license-info-card' },
							el( 'h3', null, i18n.licenseRules ),
							el( 'p', { dangerouslySetInnerHTML: html( activation.licenseRules ) } ),
							el( 'p', null, activation.revokeNote )
						),
						el(
							Panel,
							{ className: 'penci-dashboard-card penci-license-info-card penci-activate-extra-notes' },
							el( 'h3', null, i18n.activationData ),
							el( 'p', null, activation.dataIntro ),
							el(
								'ul',
								null,
								(activation.dataItems || []).map( function ( item ) {
									return el( 'li', { key: item }, item );
								} )
							),
							el( 'p', null, activation.dataStorage )
						)
					)
				)
			)
		);
	}

	function LicensePage() {
		var licenseDetails = data.licenseDetails || {};
		var detailItems = licenseDetails.items || [];
		var revokeClick = function ( event ) {
			if ( ! window.confirm( i18n.confirmRevoke ) ) {
				event.preventDefault();
			}
		};

		return el(
			Fragment,
			null,
			el( Hero, {
				title: i18n.themeLicense,
				subtitle: i18n.licenseSubtitle,
				aboutHtml: '',
				customWelcomeHtml: '',
				actions: [
					{ label: i18n.gettingStarted, href: data.urls.dashboard, isPrimary: true },
					{ label: i18n.viewDocumentation, href: data.urls.documentation, target: '_blank' },
				],
				statusTiles: [
					{ label: i18n.status, value: i18n.activated, meta: i18n.licenseConnected },
					{ label: i18n.version, value: data.themeVersion },
					{ label: i18n.license, value: licenseDetails.hasDetails ? i18n.licenseAvailable : i18n.licenseMissing },
				],
			} ),
			el( Nav ),
			licenseDetails.hasDetails ? el(
				'section',
				{ className: 'penci-dashboard-section' },
				el(
					'div',
					{ className: 'penci-dashboard-section-heading' },
					el( 'h2', null, i18n.licenseDetails ),
					el( 'p', null, i18n.licenseMaskHelp )
				),
				el(
					'div',
					{ className: 'penci-license-layout' },
					el(
						Panel,
						{ className: 'penci-dashboard-card penci-license-main-card' },
						el( 'h3', null, i18n.currentLicense ),
						el(
							'dl',
							{ className: 'penci-license-detail-list' },
							detailItems.map( function ( item ) {
								return el(
									'div',
									{ key: item.label },
									el( 'dt', null, item.label ),
									el( 'dd', null, item.value )
								);
							} )
						)
					),
					el(
						'div',
						{ className: 'penci-license-side' },
						el(
							Panel,
							{ className: 'penci-dashboard-card penci-license-info-card penci-license-danger-card' },
							el( 'h3', null, i18n.revokeLicense ),
							el( 'p', null, el( 'strong', null, i18n.important + ' ' ), i18n.revokeLicenseDesc ),
							el( AppButton, { href: data.urls.revokeLicense, isDanger: true, onClick: revokeClick }, i18n.revokeLicense )
						),
						el(
							Panel,
							{ className: 'penci-dashboard-card penci-license-info-card' },
							el( 'h3', null, i18n.continueSetup ),
							el(
								'div',
								{ className: 'penci-dashboard-card-actions' },
								el( AppButton, { href: data.urls.dashboard, isPrimary: true }, i18n.gettingStarted ),
								el( AppButton, { href: data.urls.documentation, target: '_blank' }, i18n.viewDocumentation ),
								el( AppButton, { href: data.urls.plugins }, i18n.installRecommendPlugins || i18n.installPlugins )
							)
						)
					)
				)
			) : el(
				'section',
				{ className: 'penci-dashboard-section' },
				el(
					Panel,
					{ className: 'penci-dashboard-card penci-license-main-card' },
					el( 'h2', null, i18n.noLicenseDetails ),
					el( 'p', null, i18n.noLicenseDesc ),
					el(
						'div',
						{ className: 'penci-dashboard-card-actions' },
						el( AppButton, { href: data.urls.support, target: '_blank', isPrimary: true }, i18n.contactSupport )
					)
				)
			)
		);
	}

	function Products() {
		if ( data.whiteLabel ) {
			return null;
		}

		return el(
			'section',
			{ className: 'penci-dashboard-section penci-dashboard-products' },
			el( 'h2', null, i18n.moreItems ),
			el(
				'div',
				{ className: 'penci-dashboard-product-grid' },
				el( 'a', { href: data.urls.penci, target: '_blank', rel: 'noopener noreferrer', className: 'penci-dashboard-product' },
					el( 'img', { src: data.images.penci, alt: '' } ),
					el( 'span', null, i18n.penciTitle )
				),
				el( 'a', { href: data.urls.pennews, target: '_blank', rel: 'noopener noreferrer', className: 'penci-dashboard-product' },
					el( 'img', { src: data.images.pennews, alt: '' } ),
					el( 'span', null, i18n.pennewsTitle )
				)
			)
		);
	}

	function Dashboard() {
		var pageClass = 'penci-dashboard-app';

		if ( 'soledad_active_theme' === data.currentPage ) {
			pageClass += ' penci-license-screen penci-license-activation-screen';
		}

		if ( 'soledad_theme_license' === data.currentPage ) {
			pageClass += ' penci-license-screen penci-license-detail-screen';
		}

		var content = [ el( Hero, { key: 'hero' } ), el( Nav, { key: 'nav' } ), el( GettingStarted, { key: 'getting-started' } ), el( Products, { key: 'products' } ) ];

		if ( 'soledad_active_theme' === data.currentPage ) {
			content = [ el( ActivationPage, { key: 'activation' } ) ];
		}

		if ( 'soledad_theme_license' === data.currentPage ) {
			content = [ el( LicensePage, { key: 'license' } ) ];
		}

		return el(
			'div',
			{ className: pageClass },
			data.notice && Notice ? createElement( Notice, { status: 'success', isDismissible: false }, data.notice ) : null,
			data.notice && ! Notice ? el( 'div', { className: 'notice notice-success' }, el( 'p', null, data.notice ) ) : null,
			content
		);
	}

	function mount() {
		var root = document.getElementById( 'penci-soledad-dashboard-root' );
		if ( root ) {
			render( el( Dashboard ), root );
		}
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', mount );
	} else {
		mount();
	}
}());
