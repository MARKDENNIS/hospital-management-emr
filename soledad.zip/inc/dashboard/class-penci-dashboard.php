<?php
/**
 * Add theme dashboard page
 *
 * @package Soledad
 */

/**
 * Dashboard class.
 */
class Penci_Soledad_Dashboard {


	private static $instance;

	public static function instance() {
		if ( null === static::$instance ) {
			static::$instance = new static();
		}

		return static::$instance;
	}


	public function __construct() {
		require_once __DIR__ . '/inc/custom_fonts.php';
		require_once __DIR__ . '/inc/social_order.php';
		require_once __DIR__ . '/inc/require-activation.php';
		require_once __DIR__ . '/inc/white-label.php';
		require_once __DIR__ . '/inc/custom-fonts-type.php';
		require_once __DIR__ . '/inc/patcher.php';

		if ( current_user_can( 'manage_options' ) ) {
			add_action( 'admin_menu', array( $this, 'add_menu' ) );
			add_action( 'admin_bar_menu', array( $this, 'add_bar_menu' ), 999 );
		}
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'admin_init', array( $this, 'redirect' ) );
		add_action( 'current_screen', array( $this, 'suppress_admin_notices' ), PHP_INT_MAX );
		add_action( 'admin_notices', array( $this, 'promo_notice' ) );
		add_action( 'admin_notices', array( $this, 'penci_update_notice' ) );
		add_filter( 'upload_mimes', array( $this, 'custom_mime_types' ) );
		add_action( 'wp_ajax_admin_dimiss_license_notice', array( $this, 'admin_dimiss_license_notice' ) );
		add_action( 'wp_ajax_penci_update_option', array( $this, 'penci_update_option' ) );
		add_filter( 'admin_body_class', array( $this, 'add_body_classes' ), 100 );
	}

	/**
	 * Hide WordPress admin notices on Soledad dashboard screens.
	 *
	 * @param WP_Screen $screen Current admin screen.
	 */
	public function suppress_admin_notices( $screen ) {
		$hook = $screen && isset( $screen->id ) ? $screen->id : '';

		if ( function_exists( 'penci_soledad_admin_is_theme_screen' ) && ! penci_soledad_admin_is_theme_screen( $hook, $screen ) ) {
			return;
		}

		remove_all_actions( 'admin_notices' );
		remove_all_actions( 'all_admin_notices' );
		remove_all_actions( 'network_admin_notices' );
		remove_all_actions( 'user_admin_notices' );
	}

	public function add_body_classes( $classes ) {

		$installations = Soledad_Theme_Installations::get_instance();

		if ( $installations->is_setup() && 'done' !== get_option( 'soledad_setup_status' ) ) {
			$classes .= ' soledad-setup-wizard-page';
		}

		return $classes;
	}

	public function penci_update_option() {
		check_ajax_referer( 'ajax-nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'Permission denied.' ) );
		}
		$option_name = isset( $_POST['option_name'] ) ? sanitize_text_field( wp_unslash( $_POST['option_name'] ) ) : '';
		$option_val  = isset( $_POST['option_val'] ) ? wp_unslash( $_POST['option_val'] ) : '';

		if ( $option_name && $option_val ) {
			update_option( $option_name, $option_val );
			wp_send_json_success( array( 'message' => 'Option updated successfully.' ) );
		} else {
			wp_send_json_error( array( 'message' => 'Invalid option name.' ) );
		}
	}

	public function promo_notice() {

		$penci_note   = isset( $_GET['penci-dismis'] ) ? sanitize_key( $_GET['penci-dismis'] ) : '';
		$dismis_promo = get_transient( 'penci_dismis_promo' );

		
		if ( 'penci_dismiss_promonotices' == $penci_note ) {
			set_transient( 'penci_dismis_promo', 'yes', 86400 );
		}

		if ( penci_is_new_promotion() && ! $dismis_promo ) {

			$data_pro = penci_is_new_promotion( true );
			if ( !empty( $data_pro ) ){
			?>
			<div class="notice pc-promo-notice">
				<a target="_blank" href="<?php echo $data_pro['link'];?>"><img src="<?php echo $data_pro['url'];?>" alt=""></a>
				<a class="pc-promo-notice-dismiss" href="<?php echo admin_url( '?penci-dismis=penci_dismiss_promonotices' ); ?>">×</a>
			</div>
			<?php
			}
		}
	}

	public function custom_mime_types( $mime_types ) {
		$mime_types['woff'] = 'application/x-font-woff';
		$mime_types['svg']  = 'image/svg+xml';

		return $mime_types;
	}

	public function admin_dimiss_license_notice() {
		update_option( 'penci_hide_license_notice', true );
		wp_send_json_success();
		wp_die();
	}

	/**
	 * Add theme dashboard page.
	 */
	public function add_menu() {

		$wel_page_title      = $this->get_wel_page_title();
		$wel_page_title_html = $wel_page_title;
		if ( penci_is_new_update() ) {
			$wel_page_title_html = $wel_page_title . ' <span class="update-plugins"><span class="update-count">Update</span></span>';
		}
		add_menu_page(
			$wel_page_title,
			$wel_page_title_html,
			'manage_options',
			'soledad_dashboard_welcome',
			array(
				$this,
				'dashboard_welcome',
			),
			null,
			3
		);
		add_submenu_page(
			'soledad_dashboard_welcome',
			esc_html__( 'Custom Fonts', 'soledad' ),
			esc_html__( 'Custom Fonts', 'soledad' ),
			'manage_options',
			'edit.php?post_type=penci_cfonts'
		);

		$this->replace_text_submenu();
	}

	public function get_wel_page_title() {
		$wel_page_title = get_theme_mod( 'admin_wel_page_title' );

		return $wel_page_title && get_theme_mod( 'activate_white_label' ) ? $wel_page_title : 'Soledad';
	}

	public function replace_text_submenu() {
		global $submenu;
		$submenu['soledad_dashboard_welcome'][0][0] = esc_html__( 'Welcome', 'soledad' );
	}

	function penci_get_option( $key = null, $default = false ) {
		static $data;

		$data = get_option( 'penci_soledad_options' );

		if ( empty( $data ) ) {
			return array();
		}

		if ( $key === null ) {
			return $data;
		}

		if ( isset( $data[ $key ] ) ) {
			return $data[ $key ];
		}

		return get_option( $key, $default );
	}

	public function add_bar_menu() {
		global $wp_admin_bar;
		if ( ! is_super_admin() || ! is_admin_bar_showing() ) {
			return;
		}
		$wp_admin_bar->add_menu(
			array(
				'parent' => 'site-name',
				'id'     => 'soledad-dashboard',
				'title'  => $this->get_wel_page_title(),
				'href'   => admin_url( 'admin.php?page=soledad_dashboard_welcome' ),
			)
		);
	}

	private function render_dashboard_loading() {
		?>
		<div class="penci-dashboard-loading" role="status" aria-live="polite">
			<div class="penci-dashboard-loader-mark" aria-hidden="true">
				<span class="penci-dashboard-loader-ring"></span>
				<span class="penci-dashboard-loader-dot"></span>
			</div>
			<div class="penci-dashboard-loader-content">
				<strong><?php esc_html_e( 'Loading Soledad dashboard', 'soledad' ); ?></strong>
				<span><?php esc_html_e( 'Preparing your theme workspace...', 'soledad' ); ?></span>
				<div class="penci-dashboard-loader-bars" aria-hidden="true">
					<span></span>
					<span></span>
					<span></span>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Show dashboard page.
	 */
	public function dashboard_welcome() {
		$wizard       = Soledad_Theme_Installations::get_instance();
		if ( $wizard->is_setup() && 'done' !== get_option( 'soledad_setup_status' ) ) {
			$wizard->setup_wizard_template();
		} else {
		?>
		<div class="wrap penci-about-wrap penci-dashboard-modern-wrap">
			<div id="penci-soledad-dashboard-root" class="penci-dashboard-react-root">
				<?php $this->render_dashboard_loading(); ?>
			</div>
			<noscript>
				<?php include PENCI_SOLEDAD_DIR . '/inc/dashboard/sections/welcome.php'; ?>
				<?php include PENCI_SOLEDAD_DIR . '/inc/dashboard/sections/getting-started.php'; ?>
			</noscript>
		</div>
		<?php
		}
	}

	/**
	 * Process server-side dashboard actions before the React shell renders.
	 */
	private function process_dashboard_actions() {
		$revokelicense = isset( $_GET['penci_revoke_license'] ) ? sanitize_text_field( wp_unslash( $_GET['penci_revoke_license'] ) ) : '';
		$license_nonce = isset( $_GET['revoke_none'] ) ? sanitize_text_field( wp_unslash( $_GET['revoke_none'] ) ) : '';

		if ( 'confirm' === $revokelicense && ( wp_verify_nonce( $license_nonce, 'revoke_license' ) || 'pencidesign' === $license_nonce ) ) {
			$license_data = get_option( 'penci_soledad_purchased_data' );

			if ( ! empty( $license_data['purchase_code'] ) ) {
				$req = wp_remote_post(
					'https://license.pencidesign.net/api/revoke',
					array(
						'headers'     => array(
							'Content-Type' => 'application/json',
						),
						'body'        => wp_json_encode(
							array(
								'code' => $license_data['purchase_code'],
							)
						),
						'data_format' => 'body',
						'sslverify'   => false,
					)
				);

				$res = json_decode( wp_remote_retrieve_body( $req ) );
				if ( ! empty( $res ) && isset( $res->status ) && 'success' === $res->status ) {
					delete_option( 'penci_soledad_is_activated' );
					delete_option( 'penci_soledad_purchased_data' );
					set_transient( 'penci_soledad_dashboard_notice', esc_html__( 'The license for this website has been revoked.', 'soledad' ), MINUTE_IN_SECONDS );
				}
			}
		}

		if ( isset( $_GET['penci_csync'] ) && 'parent_to_child' === sanitize_text_field( wp_unslash( $_GET['penci_csync'] ) ) ) {
			global $wp_customize;

			$nonce = isset( $_GET['nonce'] ) ? sanitize_text_field( wp_unslash( $_GET['nonce'] ) ) : '';

			if ( wp_verify_nonce( $nonce, 'penci_sync_customizer_data' ) ) {
				$mods = get_theme_mods();
				$data = array(
					'mods' => $mods ? $mods : array(),
				);

				if ( function_exists( 'wp_get_custom_css_post' ) ) {
					$data['wp_css'] = wp_get_custom_css( 'soledad' );
				}

				if ( function_exists( 'wp_update_custom_css_post' ) && isset( $data['wp_css'] ) && '' !== $data['wp_css'] ) {
					wp_update_custom_css_post( $data['wp_css'] );
				}

				do_action( 'customize_save', $wp_customize );

				foreach ( $data['mods'] as $key => $val ) {
					do_action( 'customize_save_' . $key, $wp_customize );
					set_theme_mod( $key, $val );
				}

				do_action( 'customize_save_after', $wp_customize );
				set_theme_mod( 'penci_sync_customizer_data', '1' );
				set_transient( 'penci_soledad_dashboard_notice', esc_html__( 'Customizer data has been synced to the active child theme.', 'soledad' ), MINUTE_IN_SECONDS );
			}
		}
	}

	/**
	 * Prepare React dashboard data from the existing PHP state.
	 *
	 * @return array
	 */
	private function mask_license_value( $value, $prefix = 1, $suffix = 1 ) {
		$value  = (string) $value;
		$length = strlen( $value );

		if ( $length <= $prefix + $suffix ) {
			return str_repeat( '*', $length );
		}

		return substr( $value, 0, $prefix ) . str_repeat( '*', max( 0, $length - $prefix - $suffix ) ) . substr( $value, -$suffix );
	}

	private function get_revoke_license_url() {
		return admin_url( 'admin.php?page=soledad_dashboard_welcome&penci_revoke_license=confirm&revoke_none=' . wp_create_nonce( 'revoke_license' ) );
	}

	private function get_server_id() {
		ob_start();
		if ( function_exists( 'phpinfo' ) ) {
			phpinfo( INFO_GENERAL );
		}
		echo $this->get_wel_page_title();

		return md5( ob_get_clean() );
	}

	private function get_dashboard_app_data( $current_page = 'soledad_dashboard_welcome' ) {
		$theme_data   = wp_get_theme();
		$parent_theme = $theme_data->parent();
		$is_child     = ! empty( $parent_theme );
		$theme_name   = penci_get_theme_name( 'Soledad' );
		$is_activated = (bool) get_option( 'penci_soledad_is_activated' );
		$license_data = get_option( 'penci_soledad_purchased_data' );
		$notice       = get_transient( 'penci_soledad_dashboard_notice' );
		$has_license  = ! empty( $license_data );

		if ( $notice ) {
			delete_transient( 'penci_soledad_dashboard_notice' );
		}

		$admin_wel_page_text = get_theme_mod( 'admin_wel_page_text' );
		$sync_url            = '';
		$plain_text          = static function ( $value ) {
			return wp_specialchars_decode( $value, ENT_QUOTES );
		};

		if ( $is_child && ! get_theme_mod( 'penci_sync_customizer_data' ) ) {
			$sync_url = add_query_arg(
				array(
					'penci_csync' => 'parent_to_child',
					'nonce'       => wp_create_nonce( 'penci_sync_customizer_data' ),
				),
				admin_url( 'admin.php?page=soledad_dashboard_welcome' )
			);
		}

		$nav = array(
			array(
				'page'   => 'soledad_dashboard_welcome',
				'label'  => $plain_text( esc_html__( 'Getting started', 'soledad' ) ),
				'url'    => admin_url( 'admin.php?page=soledad_dashboard_welcome' ),
			),
			array(
				'page'  => 'customize',
				'label' => $plain_text( esc_html__( 'Customize Style', 'soledad' ) ),
				'url'   => admin_url( 'customize.php' ),
			),
			array(
				'page'  => 'soledad_custom_fonts',
				'label' => $plain_text( esc_html__( 'Custom Fonts', 'soledad' ) ),
				'url'   => admin_url( 'admin.php?page=soledad_custom_fonts' ),
			),
		);

		if ( ! $is_activated ) {
			$nav[] = array(
				'page'  => 'soledad_active_theme',
				'label' => $plain_text( esc_html__( 'Active theme', 'soledad' ) ),
				'url'   => admin_url( 'admin.php?page=soledad_active_theme' ),
			);
		} elseif ( ! empty( $license_data ) ) {
			$nav[] = array(
				'page'  => 'soledad_theme_license',
				'label' => $plain_text( esc_html__( 'Theme License', 'soledad' ) ),
				'url'   => admin_url( 'admin.php?page=soledad_theme_license' ),
			);
		}

		if ( penci_is_new_update() ) {
			$nav[] = array(
				'page'  => 'soledad_new_update',
				'label' => $plain_text( esc_html__( 'New Update', 'soledad' ) ),
				'url'   => admin_url( 'admin.php?page=soledad_new_update' ),
			);
		}

		$nav[] = array(
			'page'   => 'support',
			'label'  => $plain_text( esc_html__( 'Support Forum', 'soledad' ) ),
			'url'    => 'https://pencidesign.ticksy.com/',
			'target' => '_blank',
		);

		foreach ( $nav as $index => $item ) {
			$nav[ $index ]['active'] = isset( $item['page'] ) && $current_page === $item['page'];
		}

		$license_detail_items = array();

		if ( ! empty( $license_data['buyer'] ) ) {
			$license_detail_items[] = array(
				'label' => $plain_text( esc_html__( 'Buyer Username', 'soledad' ) ),
				'value' => $this->mask_license_value( $license_data['buyer'], 1, 1 ),
			);
		}

		if ( ! empty( $license_data['bount_time'] ) ) {
			$license_detail_items[] = array(
				'label' => $plain_text( esc_html__( 'Purchase Date', 'soledad' ) ),
				'value' => $license_data['bount_time'],
			);
		}

		if ( ! empty( $license_data['purchase_code'] ) ) {
			$license_detail_items[] = array(
				'label' => $plain_text( esc_html__( 'Item Purchase Code', 'soledad' ) ),
				'value' => $this->mask_license_value( $license_data['purchase_code'], 8, 8 ),
			);
		}

		return array(
			'currentPage'       => $current_page,
			'title'             => $plain_text( $is_child ? sprintf( esc_html__( 'Welcome to %s Child Theme', 'soledad' ), $theme_name ) : sprintf( esc_html__( 'Welcome to %1$s - Version %2$s', 'soledad' ), $theme_name, $theme_data->version ) ),
			'subtitle'          => $is_child ? $plain_text( sprintf( esc_html__( 'Inherit from the %1$s Parent Theme - Version %2$s', 'soledad' ), $theme_name, $parent_theme->Version ) ) : '',
			'themeName'         => $theme_name,
			'themeVersion'      => $theme_data->version,
			'isChild'           => $is_child,
			'parentVersion'     => $is_child ? $parent_theme->Version : '',
			'isActivated'       => $is_activated,
			'hasLicense'        => $has_license,
			'hasUpdate'         => (bool) penci_is_new_update(),
			'updateVersion'     => penci_is_new_update() ? penci_is_new_update( 'version' ) : '',
			'notice'            => $notice,
			'whiteLabel'        => (bool) get_theme_mod( 'activate_white_label' ),
			'showPenciBadge'    => (bool) ( get_theme_mod( 'activate_white_label' ) && ! get_theme_mod( 'admin_wel_page_author' ) ),
			'badgeUrl'          => PENCI_SOLEDAD_URL . '/inc/dashboard/images/logo.png',
			'aboutHtml'         => sprintf( wp_kses_post( __( "Thank you for purchasing our theme! We're thrilled to have you as a valued customer.<br>You can join other users who love using Soledad to build their websites in <a target='_blank' href='https://www.facebook.com/groups/soledad/'>Soledad Users Group Here</a>. This platform is for sharing, showcasing your work, providing assistance, engaging in discussions, and staying updated.", 'soledad' ) ), penci_get_theme_author() ),
			'customWelcomeHtml' => $admin_wel_page_text ? wp_kses_post( do_shortcode( wpautop( $admin_wel_page_text ) ) ) : '',
			'nav'               => $nav,
			'urls'              => array(
				'dashboard'     => admin_url( 'admin.php?page=soledad_dashboard_welcome' ),
				'documentation' => 'https://soledad.pencidesign.net/soledad-document/',
				'plugins'       => admin_url( 'themes.php?page=tgmpa-install-plugins' ),
				'importDemo'    => admin_url( 'themes.php?page=import-demo-content' ),
				'customizer'    => admin_url( 'customize.php' ),
				'customFonts'   => admin_url( 'admin.php?page=soledad_custom_fonts' ),
				'activation'    => admin_url( 'admin.php?page=soledad_active_theme' ),
				'license'       => admin_url( 'admin.php?page=soledad_theme_license' ),
				'purchaseCode'  => 'https://help.market.envato.com/hc/en-us/articles/202822600-Where-Is-My-Purchase-Code-',
				'revokeLicense' => $this->get_revoke_license_url(),
				'videos'        => 'https://www.youtube.com/playlist?list=PL1PBMejQ2VTwp9ppl8lTQ9Tq7I3FJTT04',
				'support'       => 'https://pencidesign.ticksy.com/',
				'sync'          => $sync_url,
				'penci'         => 'https://pencidesign.net/',
				'pennews'       => 'https://themeforest.net/item/pennew-multiconcept-newsmagazine-amp-wordpress-theme/20822517',
			),
			'images'            => array(
				'penci'   => PENCI_SOLEDAD_URL . '/inc/dashboard/images/penci.jpg',
				'pennews' => PENCI_SOLEDAD_URL . '/inc/dashboard/images/pennews.jpg',
			),
			'activation'        => array(
				'serverId'       => $this->get_server_id(),
				'description'    => $plain_text( sprintf( esc_html__( 'Please activate %s to use full features of the theme. We built the activation system to prevent piracy of our themes and better serve our paying customers. Using the theme without a valid license can also create DMCA issues later.', 'soledad' ), $theme_name ) ),
				'licenseRules'   => wp_kses_post( __( 'With each license, you can use Soledad for <strong>one website</strong>. If you want to use this theme for multiple sites, please buy more licenses.', 'soledad' ) ),
				'revokeNote'     => $plain_text( esc_html__( 'After activating the theme, you can revoke the license for this website if you want to use it on another domain.', 'soledad' ) ),
				'dataIntro'      => $plain_text( esc_html__( 'To deliver customer support, access to features, and piracy prevention, the following data is sent to our servers:', 'soledad' ) ),
				'dataItems'      => array(
					$plain_text( esc_html__( 'The Envato username', 'soledad' ) ),
					$plain_text( esc_html__( 'The Envato purchase code for the item', 'soledad' ) ),
					$plain_text( esc_html__( 'The website URL you have activated the theme on', 'soledad' ) ),
					$plain_text( esc_html__( 'The server IP address that has the theme installed', 'soledad' ) ),
				),
				'dataStorage'    => $plain_text( esc_html__( 'The data is stored on a server located in the US, and we do not share any of this information with third-party partners.', 'soledad' ) ),
			),
			'licenseDetails'    => array(
				'items'      => $license_detail_items,
				'hasDetails' => $has_license,
			),
			'i18n'              => array(
				'status'               => $plain_text( esc_html__( 'Status', 'soledad' ) ),
				'activated'            => $plain_text( esc_html__( 'Activated', 'soledad' ) ),
				'notActivated'         => $plain_text( esc_html__( 'Not activated', 'soledad' ) ),
				'actionRequired'       => $plain_text( esc_html__( 'Action required', 'soledad' ) ),
				'version'              => $plain_text( esc_html__( 'Version', 'soledad' ) ),
				'envatoPurchaseCode'   => $plain_text( esc_html__( 'Envato purchase code', 'soledad' ) ),
				'oneWebsiteLicense'    => $plain_text( esc_html__( 'One website per license', 'soledad' ) ),
				'updateAvailable'      => $plain_text( esc_html__( 'Update available', 'soledad' ) ),
				'upToDate'             => $plain_text( esc_html__( 'Ready', 'soledad' ) ),
				'viewDocumentation'    => $plain_text( esc_html__( 'View Documentation', 'soledad' ) ),
				'findPurchaseCode'     => $plain_text( esc_html__( 'Find Your Purchase Code', 'soledad' ) ),
				'enterPurchaseCode'    => $plain_text( esc_html__( 'Enter Purchase Code', 'soledad' ) ),
				'activateSoledad'      => $plain_text( esc_html__( 'Activate Soledad', 'soledad' ) ),
				'activateSubtitle'     => $plain_text( esc_html__( 'Unlock theme updates, support access, demo imports, and full dashboard features with your Envato purchase code.', 'soledad' ) ),
				'activation'           => $plain_text( esc_html__( 'Activation', 'soledad' ) ),
				'activationHelp'       => $plain_text( esc_html__( 'Paste the purchase code from your Envato account.', 'soledad' ) ),
				'activateTheme'        => $plain_text( esc_html__( 'Activate theme', 'soledad' ) ),
				'purchaseCode'         => $plain_text( esc_html__( 'Your Purchase Code', 'soledad' ) ),
				'codeRequired'         => $plain_text( esc_html__( 'Code is required', 'soledad' ) ),
				'codeTooShort'         => $plain_text( esc_html__( 'Code is too short', 'soledad' ) ),
				'codeInvalid'          => $plain_text( esc_html__( 'Invalid purchase code. Please check it again.', 'soledad' ) ),
				'licenseRules'         => $plain_text( esc_html__( 'License rules', 'soledad' ) ),
				'activationData'       => $plain_text( esc_html__( 'Data sent during activation', 'soledad' ) ),
				'installPlugins'       => $plain_text( esc_html__( 'Install Plugins', 'soledad' ) ),
				'installRecommendPlugins' => $plain_text( esc_html__( 'Install Recommend Plugins', 'soledad' ) ),
				'importDemo'           => $plain_text( esc_html__( 'Import Demo Now', 'soledad' ) ),
				'startCustomize'       => $plain_text( esc_html__( 'Customize Theme', 'soledad' ) ),
				'syncCustomizer'       => $plain_text( esc_html__( 'Sync Customizer Data', 'soledad' ) ),
				'readDocumentation'    => $plain_text( esc_html__( 'Read Documentation', 'soledad' ) ),
				'viewVideos'           => $plain_text( esc_html__( 'View Video Tutorials', 'soledad' ) ),
				'revokeLicense'        => $plain_text( esc_html__( 'Revoke License', 'soledad' ) ),
				'moreItems'            => $plain_text( esc_html__( 'More items by PenciDesign', 'soledad' ) ),
				'step'                 => $plain_text( esc_html__( 'Step', 'soledad' ) ),
				'quickActions'         => $plain_text( esc_html__( 'Quick actions', 'soledad' ) ),
				'gettingStarted'       => $plain_text( esc_html__( 'Getting started', 'soledad' ) ),
				'setupGuide'           => $plain_text( esc_html__( 'Setup guide', 'soledad' ) ),
				'resources'            => $plain_text( esc_html__( 'Resources', 'soledad' ) ),
				'license'              => $plain_text( esc_html__( 'License', 'soledad' ) ),
				'installTitle'         => $plain_text( esc_html__( 'Install & Activate Plugins', 'soledad' ) ),
				'demoTitle'            => $plain_text( esc_html__( 'Import Demo Data (Optional)', 'soledad' ) ),
				'customizeTitle'       => $plain_text( esc_html__( 'Customize the Theme', 'soledad' ) ),
				'docsTitle'            => $plain_text( esc_html__( 'Read Full Documentation', 'soledad' ) ),
				'videosTitle'          => $plain_text( esc_html__( 'Video Tutorials', 'soledad' ) ),
				'licenseTitle'         => $plain_text( esc_html__( 'Revoke License', 'soledad' ) ),
				'themeLicense'         => $plain_text( esc_html__( 'Theme License', 'soledad' ) ),
				'licenseSubtitle'      => $plain_text( esc_html__( 'Review the license connected to this website, revoke it when moving domains, or continue setup from the links below.', 'soledad' ) ),
				'licenseConnected'     => $plain_text( esc_html__( 'License connected', 'soledad' ) ),
				'licenseAvailable'     => $plain_text( esc_html__( 'Available', 'soledad' ) ),
				'licenseMissing'       => $plain_text( esc_html__( 'Missing details', 'soledad' ) ),
				'licenseDetails'       => $plain_text( esc_html__( 'License details', 'soledad' ) ),
				'licenseMaskHelp'      => $plain_text( esc_html__( 'Sensitive license fields are masked for display.', 'soledad' ) ),
				'currentLicense'       => $plain_text( esc_html__( 'Current license', 'soledad' ) ),
				'important'            => $plain_text( esc_html__( 'Important:', 'soledad' ) ),
				'revokeLicenseDesc'    => $plain_text( esc_html__( 'If you want to use the license on another domain, revoke the license for this website by clicking the button below.', 'soledad' ) ),
				'confirmRevoke'        => $plain_text( esc_html__( 'Are you sure?', 'soledad' ) ),
				'continueSetup'        => $plain_text( esc_html__( 'Continue setup', 'soledad' ) ),
				'noLicenseDetails'     => $plain_text( esc_html__( 'No license details found', 'soledad' ) ),
				'noLicenseDesc'        => $plain_text( esc_html__( 'The theme is marked as activated, but no purchase details are stored for this website. If you need to reconnect your license, contact PenciDesign support.', 'soledad' ) ),
				'contactSupport'       => $plain_text( esc_html__( 'Contact Support', 'soledad' ) ),
				'pluginsDesc'          => $plain_text( sprintf( esc_html__( '%s does not require any plugins. All plugins are additional features that you can choose to install and use. If you want to import a demo, please install and activate the Penci Soledad Demo Importer plugin.', 'soledad' ), $theme_name ) ),
				'pluginsHelp'          => $plain_text( esc_html__( "We recommend checking the theme's documentation first to learn how to configure it.", 'soledad' ) ),
				'demoDescHtml'         => wp_kses_post( __( '<strong>Important:</strong> If your site is a new site with no old posts/pages, you can perform a full import as normal by using the "Import Demo Style" and "Import Demo Content" options. However, if your site has old data such as posts/pages, please only perform an import using the <strong>"Import Demo Style"</strong> option.<br><br>If you receive the message <strong>"Sorry, you are not allowed to access this page"</strong> when clicking the button "Import Demo Now" below, it means that you have not installed or activated the <strong>"Penci Soledad Demo Importer"</strong> plugin. Please go to the Install Plugins page and do so.', 'soledad' ) ),
				'customizeDescHtml'    => wp_kses_post( __( 'By using the WordPress Customizer, you can easily customize every general aspect of the theme.<br><br>If you wish to configure your homepage using Elementor or WPBakery Page Builder plugin, please refer to the <a target="_blank" href="https://soledad.pencidesign.net/soledad-document/#homepage">documentation guide</a> under the "Homepage" section.', 'soledad' ) ),
				'syncDesc'             => $plain_text( esc_html__( 'If you previously customized the parent theme, sync those settings to the active child theme to resolve style, logo, menu, and other related issues.', 'soledad' ) ),
				'docsDesc'             => $plain_text( esc_html__( 'Need any help setting up and configuring the theme? Please check our full documentation for detailed information on how to use it first.', 'soledad' ) ),
				'videosDesc'           => $plain_text( esc_html__( 'We believe that the easiest way to learn is by watching video tutorials. We have a growing library of narrated video tutorials to help you do just that.', 'soledad' ) ),
				'licenseDescHtml'      => wp_kses_post( __( '<strong>Important:</strong> If you want to use the license on another domain, please revoke the license for this website on the Theme License page.', 'soledad' ) ),
				'penciTitle'           => $plain_text( esc_html__( 'All WordPress Themes from PenciDesign', 'soledad' ) ),
				'pennewsTitle'         => $plain_text( esc_html__( 'PenNews - News, Magazine, Business, Portfolio, and Landing AMP WordPress Theme', 'soledad' ) ),
			),
		);
	}

	/**
	 * Enqueue scripts for dashboard page.
	 *
	 * @param string $hook Page hook.
	 */
	public function enqueue_scripts( $hook ) {

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( function_exists( 'penci_soledad_admin_is_theme_screen' ) && ! penci_soledad_admin_is_theme_screen( $hook, $screen ) ) {
			return;
		}

		$ver = current_time( 'timestamp' );

		wp_enqueue_media();
		wp_enqueue_style( 'dashboard-style', PENCI_SOLEDAD_URL . '/inc/dashboard/css/dashboard-style.css', array(), PENCI_SOLEDAD_VERSION );
		wp_enqueue_script( 'soledad-button-script', PENCI_SOLEDAD_URL . '/inc/woocommerce/js/jquery-grid-picker.js', array( 'jquery' ), PENCI_SOLEDAD_VERSION );
		wp_enqueue_script( 'soledad-dashboard-script', PENCI_SOLEDAD_URL . '/inc/dashboard/js/script.js', array( 'jquery' ), $ver );

		$page        = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$react_pages = array( 'soledad_dashboard_welcome', 'soledad_active_theme', 'soledad_theme_license' );

		if ( in_array( $page, $react_pages, true ) ) {
			$this->process_dashboard_actions();
			wp_enqueue_style( 'wp-components' );
			wp_enqueue_script(
				'soledad-dashboard-react',
				PENCI_SOLEDAD_URL . '/inc/dashboard/js/dashboard-react.js',
				array( 'wp-element', 'wp-components', 'wp-i18n' ),
				PENCI_SOLEDAD_VERSION,
				true
			);
			wp_localize_script( 'soledad-dashboard-react', 'PENCISOLEDAD_DASHBOARD', $this->get_dashboard_app_data( $page ) );
		}

		$localize_script = array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'ajax-nonce' ),
			'patcher_nonce'   => wp_create_nonce( 'patcher_nonce' ),
			'domain'  => get_home_url( '/' ),
		);
		wp_localize_script( 'soledad-dashboard-script', 'PENCIDASHBOARD', $localize_script );
	}

	/**
	 * Add notice message when a new version released
	 *
	 * @param none.
	 */
	public function penci_update_notice() {
		if ( penci_is_new_update() ) {
			$penci_note     = isset( $_GET['penci-dismis'] ) ? $_GET['penci-dismis'] : '';
			$latest_version = penci_is_new_update( 'version' );
			$dismis_version = get_transient( 'penci_dismis_update_version' );
			if ( ! $dismis_version || version_compare( $latest_version, $dismis_version, '>' ) ) {
				update_option( 'penci_dismiss_update_notices', '' );
			}
			if ( 'penci_dismiss_updatenotices' == $penci_note ) {
				update_option( 'penci_dismiss_update_notices', 'yes' );
				set_transient( 'penci_dismis_update_version', $latest_version, 2592000 );
			}
			$penci_dismis_notes = get_option( 'penci_dismiss_update_notices', '' );

			if ( 'yes' != $penci_dismis_notes ) {
				?>
				<div class="notice pc-update-notice">
					<p class="pc-updaten-title">New Update Available!</p>
					<p>There is a new version of the theme available! Update your theme to get new features and bug
						fixes.</p>
					<p>You can check <a href="https://pencidesign.ticksy.com/article/15633/" target="_blank">this
							guide</a> to know how to enable updates with one click.</p>
					<p>You can click <a
								href="https://themeforest.net/item/soledad-multiconcept-blogmagazine-wp-theme/12945398#item-description__update-changelog"
								target="_blank">here</a> to check what's new in the newest version also.</p>
					<p><a style="text-decoration: none; opacity: 0.8;"
							href="<?php echo admin_url( '?penci-dismis=penci_dismiss_updatenotices' ); ?>">Dismiss this
							update.</a></p>
				</div>
				<?php
			}
		}
	}

	/**
	 * Redirect to dashboard page after theme activation.
	 */
	public function redirect() {
		global $pagenow;

		$install_wizzard = true;
		$url = admin_url( 'admin.php?page=soledad_dashboard_welcome' );

		if ( 'done' === get_option( 'soledad_setup_status' ) ) {
			$install_wizzard = false;
		}

		$args = array(
			'page' => 'soledad_dashboard_welcome',
			'tab'  => 'wizard',
		);

		if ( $install_wizzard ) {
			$url = esc_url_raw( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		}

		if ( is_admin() && isset( $_GET['activated'] ) && 'themes.php' === $pagenow ) {
			wp_safe_redirect( $url );
			exit;
		}
	}
}

if ( ! function_exists( 'penci_is_plugin_active' ) ) {
	function penci_is_plugin_active( $class, $slug ) {
		return $class->is_plugin_active( $slug );
	}
}

function penci_update_toolbar_link( $wp_admin_bar ) {
	$tgm_instance    = TGM_Plugin_Activation::get_instance();
	$default_plugins = array(
		'penci-shortcodes',
		'vafpress-post-formats-ui-develop',
		'penci-soledad-slider',
		'penci-portfolio',
		'penci-recipe',
		'penci-review',
		'penci-soledad-demo-importer',
		'penci-soledad-amp',
	);

	foreach ( $tgm_instance->plugins as $id => $detail ) {
		if ( in_array( $id, $default_plugins ) && penci_is_plugin_active( $tgm_instance, $id ) && $tgm_instance->does_plugin_require_update( $id ) ) {
			$penci_icon = '<svg style="position: relative; top:4px;margin-right: 5px;" version="1.0" xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" viewBox="0 0 26.000000 26.000000" preserveAspectRatio="xMidYMid meet">
				<g transform="translate(0.000000,26.000000) scale(0.100000,-0.100000)" fill="#ffffff" stroke="none">
					<path d="M72 202 l-62 -60 0 -66 0 -66 125 0 125 0 0 61 0 61 -63 65 -62 64
				-63 -59z m73 28 c3 -5 -3 -10 -15 -10 -12 0 -18 5 -15 10 3 6 10 10 15 10 5 0
				12 -4 15 -10z m57 -57 c34 -33 36 -38 20 -49 -14 -10 -21 -8 -45 12 -36 31
				-62 30 -93 -1 -21 -21 -28 -23 -44 -13 -19 12 -18 14 17 50 51 52 92 52 145 1z
				m-77 -93 c0 -59 -1 -60 -27 -60 -26 0 -28 3 -28 42 0 24 7 49 17 60 28 32 38
				21 38 -42z m49 44 c10 -9 16 -33 16 -60 0 -40 -2 -44 -25 -44 -24 0 -25 3 -25
				60 0 62 7 71 34 44z m-130 -20 c9 -8 16 -31 16 -50 0 -27 -4 -34 -20 -34 -17
				0 -20 7 -20 50 0 28 2 50 4 50 3 0 12 -7 20 -16z m201 -34 c0 -44 -3 -50 -20
				-50 -18 0 -20 5 -17 38 4 35 17 62 31 62 3 0 6 -22 6 -50z"></path>
					<path d="M90 70 c0 -5 5 -10 10 -10 6 0 10 5 10 10 0 6 -4 10 -10 10 -5 0 -10
				-4 -10 -10z"></path>
				</g>
			</svg>';

			$args = array(
				'id'    => 'penci-update-notice',
				'title' => $penci_icon . ' Soledad - Notifications',
				'href'  => '#',
				'meta'  => array(
					'class' => 'penci-update-notice-button',
					'title' => 'Soledad - Notifications',
				),
			);
			$wp_admin_bar->add_node( $args );

			$args = array(
				'id'     => 'penci-update-notice-link',
				'title'  => 'Some Plugins Need to Update',
				'href'   => admin_url( 'themes.php?page=tgmpa-install-plugins&plugin_status=update' ),
				'parent' => 'penci-update-notice',
				'meta'   => array(
					'class' => 'penci-update-notice-btn',
					'title' => 'Some Plugins Need to Update',
				),
			);
			$wp_admin_bar->add_node( $args );
		}
	}
}

add_action( 'admin_bar_menu', 'penci_update_toolbar_link', 50 );
Penci_Soledad_Dashboard::instance();
