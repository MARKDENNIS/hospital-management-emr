<?php
if ( ! function_exists( 'penci_soledad_is_activated' ) ) {
	function penci_soledad_is_activated() {
		return get_option( 'penci_soledad_is_activated' );
	}
}

if ( ! function_exists( 'penci_soledad_is_license' ) ) {
	function penci_soledad_is_license() {
		$license_data = get_option( 'penci_soledad_purchased_data' );
		if ( ! empty( $license_data ) ) {
			return true;
		} else {
			return false;
		}
	}
}

if ( ! class_exists( 'Penci_Require_Active' ) ) {
	class Penci_Require_Active {
		protected $time_max = 2592000; // 30 days
		protected $theme_info;

		public function __construct() {
			// Not run code require active theme on the admin
			if ( ! is_admin() ) {
				return;
			}

			$this->theme_info = wp_get_theme();
			$this->main();

			add_action( 'wp_ajax_nopriv_penci_check_envato_code', array( $this, 'do_check_envato_code' ) );
			add_action( 'wp_ajax_penci_check_envato_code', array( $this, 'do_check_envato_code' ) );

			add_action( 'admin_enqueue_scripts', array( $this, 'add_admin_scripts' ), 10, 1 );
		}

		public function main() {

			$curent_time             = time();
			$active_status_last_time = get_option( 'soledad_active_status_last_time' );

			add_action( 'admin_menu', array( $this, 'add_submenu_page' ), 15 );

			if ( empty( $active_status_last_time ) ) {
				update_option( 'soledad_active_status_last_time', $curent_time );
			} else {
				if ( get_option( 'penci_soledad_is_activated' ) || get_option( 'penci_hide_license_notice' ) ) {
					return;
				}
			}
		}

		public function add_admin_scripts( $hook ) {
			if ( get_option( 'penci_soledad_is_activated' ) ) {
				return;
			}

			$active_status_last_time = get_option( 'soledad_active_status_last_time' );
			$time_delta              = time() - $active_status_last_time;
			$time_max                = $this->time_max;

			if ( $time_delta < $time_max ) {
				return;
			}

			if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
				wp_enqueue_script( 'soledad-editor-script', PENCI_SOLEDAD_URL . '/inc/dashboard/js/edit-post.js', array( 'jquery' ) );
			}
		}

		function add_submenu_page() {
			$is_activated = get_option( 'penci_soledad_is_activated' );
			if ( ! $is_activated ) {
				add_submenu_page(
					'soledad_dashboard_welcome',
					esc_html__( 'Active theme', 'soledad' ),
					esc_html__( 'Active theme', 'soledad' ),
					'manage_options',
					'soledad_active_theme',
					array(
						$this,
						'require_active_page',
					)
				);
				add_action( 'admin_notices', array( $this, 'validation_notice' ) );
			} elseif ( $is_activated && penci_soledad_is_license() ) {
				add_submenu_page(
					'soledad_dashboard_welcome',
					esc_html__( 'Theme License', 'soledad' ),
					esc_html__( 'Theme License', 'soledad' ),
					'manage_options',
					'soledad_theme_license',
					array(
						$this,
						'theme_license_page',
					)
				);
			}

			if ( penci_is_new_update() ) {
				$version    = penci_is_new_update( 'version' );
				$page_title = esc_html__( 'New Update', 'soledad' );
				$menu_title = $page_title . ' <span class="update-plugins"><span class="update-count">' . $version . '</span></span>';
				add_submenu_page(
					'soledad_dashboard_welcome',
					$page_title,
					$menu_title,
					'manage_options',
					'soledad_new_update',
					array(
						$this,
						'new_update_page',
					)
				);
			}
		}


		public function get_server_id() {
			ob_start();
			if ( function_exists( 'phpinfo' ) ) {
				phpinfo( INFO_GENERAL );
			}
			echo $this->theme_info->name;

			return md5( ob_get_clean() );
		}

		/**
		 * Show notice active theme
		 */
		function validation_notice() {
			$link_page_active = admin_url( 'admin.php?page=soledad_active_theme' );
			?>
			<div class="penci-license-notice notice notice-success is-dismissible"
				style="background: #b70303; color: #fff; border-color: #00a32a;padding: 15px 25px 15px 120px;position: relative;">
				<i style="font-size: 100px;position: absolute;left: 10px;top: 50%;transform: translateY(-50%);width: auto;height: auto;"
					class="dashicons dashicons-warning"></i>
				<p style="font-size: 14px">
					<a class="penci-notice-logo" href="<?php echo esc_url( 'https://pencidesign.net/' ); ?>"
						target="_blank"><?php $this->get_icon_penci(); ?></a>
					<?php _e( '<strong>The system can\'t detect your purchase. Please activate Soledad to use full features of the theme</strong>. We\'re sorry about this but we built the activation system to prevent piracy of our themes in the internet, we can do better serve our paying customers.', 'soledad' ); ?>
				</p>
				<p style="font-size: 14px">
					<?php esc_html_e( 'You can', 'soledad' ); ?>
					<a style="color: #0bf948;"
						href="<?php echo( $link_page_active ); ?>"><?php esc_html_e( 'click here to activate the theme', 'soledad' ); ?></a>
					- <?php _e( 'If you have issues with this please contact us via <a rel="nofollow" href="http://pencidesign.ticksy.com/" target="_blank" style="color: #0bf948;">our support forum</a> or <a style="color: #0bf948;" rel="nofollow" href="https://themeforest.net/user/pencidesign#contact" target="_blank">our contact form</a>. This notice will be removed after you activated the theme.', 'soledad' ); ?>
				</p>
				<p style="font-size: 14px"><?php _e( 'You can check the documentation for this theme <a style="color: #0bf948;" href="https://soledad.pencidesign.net/soledad-document/" target="_blank">here</a> to know how to config this theme also.', 'soledad' ); ?></p>
			</div>
			<?php
		}

		/**
		 * Get icon penci
		 */
		function get_icon_penci() {
			?>
			<svg style="position: relative; top:4px;margin-right: 5px;" version="1.0" xmlns="http://www.w3.org/2000/svg"
				width="18px" height="18px" viewBox="0 0 26.000000 26.000000"
				preserveAspectRatio="xMidYMid meet">
				<g transform="translate(0.000000,26.000000) scale(0.100000,-0.100000)"
					fill="#ffffff" stroke="none">
					<path d="M72 202 l-62 -60 0 -66 0 -66 125 0 125 0 0 61 0 61 -63 65 -62 64
				-63 -59z m73 28 c3 -5 -3 -10 -15 -10 -12 0 -18 5 -15 10 3 6 10 10 15 10 5 0
				12 -4 15 -10z m57 -57 c34 -33 36 -38 20 -49 -14 -10 -21 -8 -45 12 -36 31
				-62 30 -93 -1 -21 -21 -28 -23 -44 -13 -19 12 -18 14 17 50 51 52 92 52 145 1z
				m-77 -93 c0 -59 -1 -60 -27 -60 -26 0 -28 3 -28 42 0 24 7 49 17 60 28 32 38
				21 38 -42z m49 44 c10 -9 16 -33 16 -60 0 -40 -2 -44 -25 -44 -24 0 -25 3 -25
				60 0 62 7 71 34 44z m-130 -20 c9 -8 16 -31 16 -50 0 -27 -4 -34 -20 -34 -17
				0 -20 7 -20 50 0 28 2 50 4 50 3 0 12 -7 20 -16z m201 -34 c0 -44 -3 -50 -20
				-50 -18 0 -20 5 -17 38 4 35 17 62 31 62 3 0 6 -22 6 -50z"/>
					<path d="M90 70 c0 -5 5 -10 10 -10 6 0 10 5 10 10 0 6 -4 10 -10 10 -5 0 -10
				-4 -10 -10z"/>
				</g>
			</svg>
			<?php
		}

		private function get_dashboard_nav_items( $active_page ) {
			$is_activated = get_option( 'penci_soledad_is_activated' );
			$license_data = get_option( 'penci_soledad_purchased_data' );
			$nav_items    = array(
				array(
					'page'  => 'soledad_dashboard_welcome',
					'label' => esc_html__( 'Getting started', 'soledad' ),
					'url'   => admin_url( 'admin.php?page=soledad_dashboard_welcome' ),
				),
				array(
					'page'  => 'customize',
					'label' => esc_html__( 'Customize Style', 'soledad' ),
					'url'   => admin_url( 'customize.php' ),
				),
				array(
					'page'  => 'soledad_custom_fonts',
					'label' => esc_html__( 'Custom Fonts', 'soledad' ),
					'url'   => admin_url( 'admin.php?page=soledad_custom_fonts' ),
				),
			);

			if ( ! $is_activated ) {
				$nav_items[] = array(
					'page'  => 'soledad_active_theme',
					'label' => esc_html__( 'Active theme', 'soledad' ),
					'url'   => admin_url( 'admin.php?page=soledad_active_theme' ),
				);
			} elseif ( ! empty( $license_data ) ) {
				$nav_items[] = array(
					'page'  => 'soledad_theme_license',
					'label' => esc_html__( 'Theme License', 'soledad' ),
					'url'   => admin_url( 'admin.php?page=soledad_theme_license' ),
				);
			}

			if ( penci_is_new_update() ) {
				$nav_items[] = array(
					'page'  => 'soledad_new_update',
					'label' => esc_html__( 'New Update', 'soledad' ),
					'url'   => admin_url( 'admin.php?page=soledad_new_update' ),
				);
			}

			$nav_items[] = array(
				'page'   => 'support',
				'label'  => esc_html__( 'Support Forum', 'soledad' ),
				'url'    => 'https://pencidesign.ticksy.com/',
				'target' => '_blank',
			);

			foreach ( $nav_items as $index => $item ) {
				$nav_items[ $index ]['active'] = $active_page === $item['page'];
			}

			return $nav_items;
		}

		private function render_dashboard_nav( $active_page ) {
			?>
			<nav class="penci-dashboard-nav" aria-label="<?php esc_attr_e( 'Soledad admin navigation', 'soledad' ); ?>">
				<?php foreach ( $this->get_dashboard_nav_items( $active_page ) as $item ) : ?>
					<a href="<?php echo esc_url( $item['url'] ); ?>"
						<?php echo ! empty( $item['target'] ) ? 'target="' . esc_attr( $item['target'] ) . '" rel="noopener noreferrer"' : ''; ?>
						class="<?php echo ! empty( $item['active'] ) ? 'is-active' : ''; ?>"
						<?php echo ! empty( $item['active'] ) ? 'aria-current="page"' : ''; ?>>
						<?php echo esc_html( $item['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>
			<?php
		}

		private function render_status_tile( $label, $value, $meta = '' ) {
			?>
			<div class="penci-dashboard-status-tile">
				<span class="penci-dashboard-status-label"><?php echo esc_html( $label ); ?></span>
				<strong><?php echo esc_html( $value ); ?></strong>
				<?php if ( $meta ) : ?>
					<span class="penci-dashboard-status-meta"><?php echo esc_html( $meta ); ?></span>
				<?php endif; ?>
			</div>
			<?php
		}

		private function mask_license_value( $value, $prefix = 1, $suffix = 1 ) {
			$value  = (string) $value;
			$length = strlen( $value );

			if ( $length <= $prefix + $suffix ) {
				return str_repeat( '*', $length );
			}

			return substr( $value, 0, $prefix ) . str_repeat( '*', max( 0, $length - $prefix - $suffix ) ) . substr( $value, -$suffix );
		}

		private function get_revoke_license_url() {
			return admin_url( 'admin.php?page=soledad_dashboard_welcome&penci_revoke_license=confirm&revoke_none=' . wp_create_nonce( 'revoke_license' ) );
		}

		public function require_active_page() {
			?>
			<div class="wrap penci-about-wrap penci-dashboard-modern-wrap">
				<div id="penci-soledad-dashboard-root" class="penci-dashboard-react-root">
					<div class="penci-dashboard-loading" role="status" aria-live="polite">
						<div class="penci-dashboard-loader-mark" aria-hidden="true">
							<span class="penci-dashboard-loader-ring"></span>
							<span class="penci-dashboard-loader-dot"></span>
						</div>
						<div class="penci-dashboard-loader-content">
							<strong><?php esc_html_e( 'Loading Soledad dashboard', 'soledad' ); ?></strong>
							<span><?php esc_html_e( 'Preparing your theme workspace...', 'soledad' ); ?></span>
							<div class="penci-dashboard-loader-bars" aria-hidden="true">
								<span></span>
								<span></span>
								<span></span>
							</div>
						</div>
					</div>
				</div>
				<noscript>
					<p><?php esc_html_e( 'JavaScript is required to activate Soledad from this dashboard page.', 'soledad' ); ?></p>
				</noscript>
			</div>
			<?php
		}

		public function theme_license_page() {
			?>
			<div class="wrap penci-about-wrap penci-dashboard-modern-wrap">
				<div id="penci-soledad-dashboard-root" class="penci-dashboard-react-root">
					<div class="penci-dashboard-loading" role="status" aria-live="polite">
						<div class="penci-dashboard-loader-mark" aria-hidden="true">
							<span class="penci-dashboard-loader-ring"></span>
							<span class="penci-dashboard-loader-dot"></span>
						</div>
						<div class="penci-dashboard-loader-content">
							<strong><?php esc_html_e( 'Loading Soledad dashboard', 'soledad' ); ?></strong>
							<span><?php esc_html_e( 'Preparing your theme workspace...', 'soledad' ); ?></span>
							<div class="penci-dashboard-loader-bars" aria-hidden="true">
								<span></span>
								<span></span>
								<span></span>
							</div>
						</div>
					</div>
				</div>
				<noscript>
					<p><?php esc_html_e( 'JavaScript is required to manage your Soledad license from this dashboard page.', 'soledad' ); ?></p>
				</noscript>
			</div>
			<?php
		}

		public function new_update_page() {
			$new_version = penci_is_new_update( 'version' );
			?>
			<div class="wrap about-wrap penci-about-wrap penci-active-theme penci-dashboard-wapper">
				<?php include PENCI_SOLEDAD_DIR . '/inc/dashboard/sections/welcome.php'; ?>
				<h2 class="nav-tab-wrapper">
					<a href="<?php echo admin_url( 'admin.php?page=soledad_dashboard_welcome' ); ?>"
						class="nav-tab"><?php esc_html_e( 'Getting started', 'soledad' ); ?></a>
					<a href="<?php echo admin_url( 'customize.php' ); ?>"
						class="nav-tab"><?php esc_html_e( 'Customize Style', 'soledad' ); ?></a>
					<a href="<?php echo admin_url( 'admin.php?page=soledad_custom_fonts' ); ?>"
						class="nav-tab"><?php esc_html_e( 'Custom Fonts', 'soledad' ); ?></a>
					<a href="<?php echo admin_url( 'admin.php?page=soledad_theme_license' ); ?>"
						class="nav-tab"><?php esc_html_e( 'Theme License', 'soledad' ); ?></a>
					<a href="<?php echo admin_url( 'admin.php?page=soledad_new_update' ); ?>"
						class="nav-tab nav-tab-active"><?php esc_html_e( 'New Update', 'soledad' ); ?></a>
					<a href="https://pencidesign.ticksy.com/" target="_blank"
						class="nav-tab"><?php esc_html_e( 'Support Forum', 'soledad' ); ?></a>
				</h2>
				<div class="penci-activate-wrap gt-tab-pane gt-is-active">
					<div class="penci-activate-envato-code">
						<div class="penci-activate-code-title"><?php esc_html_e( 'Update Soledad Theme', 'soledad' ); ?></div>
						<p class="penci-license-detail-desc">
							<?php esc_html_e( 'A new version of Soledad theme just released - Soledad Theme version ', 'soledad' ); ?><?php echo $new_version; ?>
							<br>
							<?php esc_html_e( 'Please update the theme to get the latest version.', 'soledad' ); ?>
						</p>
						<p class="penci-license-detail-desc">
							<?php _e( 'To enable Automatic Theme Updates, please check <a style="text-decoration: underline; color: #0043ff;" href="https://pencidesign.ticksy.com/article/15633/" target="_blank">this guide</a>', 'soledad' ); ?>
						</p>
						<p class="penci-license-detail-desc">
							<?php _e( 'You can click <a style="text-decoration: underline; color: #0043ff;" href="https://themeforest.net/item/soledad-multiconcept-blogmagazine-wp-theme/12945398#item-description__update-changelog" target="_blank">here</a> to check what\'s new in the newest version also.', 'soledad' ); ?>
						</p>
					</div>
				</div>
			</div>
			<?php
		}

		public function do_check_envato_code() {
			$code    = isset( $_POST['code'] ) ? $_POST['code'] : '';
			$code    = trim( $code );
			$domain  = get_home_url( '/' );
			$item_id = 12945398;

			$req = wp_remote_post(
				'https://license.pencidesign.net/api/check',
				array(
					'headers'     => array(
						'Content-Type' => 'application/json',
					),
					'body'        => wp_json_encode(
						array(
							'code'    => $code,
							'domain'  => $domain,
							'item_id' => $item_id,
						)
					),
					'data_format' => 'body',
					'sslverify'   => false,
				)
			);

			$body = wp_remote_retrieve_body( $req );
			$res  = json_decode( $body );

			if ( ! empty( $res ) && $res->status === 'success' ) {
				$data                        = $res->data;
				$array_data                  = array();
				$array_data['purchase_code'] = $code;
				$time_now                    = strtotime( '+30 days' );
				if ( $time_now ) {
					$array_data['time_notice'] = $time_now;
				}
				if ( isset( $data->supported_until ) ) {
					$date                     = new DateTime( $data->supported_until );
					$support_to               = $date->format( 'Y-m-d H:i:s' );
					$array_data['support_to'] = $support_to; /* Cover to Unix timestamps use strtotime() */
				}

				if ( isset( $data->sold_at ) ) {
					$boughtdate               = new DateTime( $data->sold_at );
					$bount_time               = $boughtdate->format( 'Y-m-d H:i:s' );
					$array_data['bount_time'] = $bount_time; /* Cover to Unix timestamps use strtotime() */
				}

				if ( isset( $data->buyer ) ) {
					$array_data['buyer'] = $data->buyer;
				}

				if ( isset( $data->purchase_count ) ) {
					$array_data['purchase_count'] = $data->purchase_count;
				}

				if ( isset( $data->amount ) ) {
					$array_data['amount'] = $data->amount;
				}

				update_option( strrev( 'kcehc_etadilav_icnep' ), strtotime( '+30 days' ) );
				update_option( strrev( 'detavitca_si_dadelos_icnep' ), 1 );
				update_option( strrev( 'atad_desahcrup_dadelos_icnep' ), $array_data );
				update_option( strrev( 'mc_sdaol_icnep' ), 'load' );
				wp_send_json_success( array( 'success' => true ) );
			} else {
				wp_send_json_error(
					array(
						'success' => false,
						'message' => $res->message,
					)
				);
			}
		}

		public function theme_purchase_exists( $token, $page = '' ) {
			$list_themes = $this->get_list_theme_purchase( $token );

			if ( ! $list_themes ) {
				return false;
			}

			foreach ( $list_themes as $theme ) {

				if ( isset( $theme['id'] ) && '12945398' == $theme['id'] ) {
					return true;
				}
			}

			if ( 100 === count( $list_themes ) ) {

				if ( ! $page ) {
					$page = 2;
				} else {
					$page = $page + 1;
				}

				$page = ( ! $page ) ? 2 : $page + 1;

				return $this->theme_purchase_exists( $token, $page );
			}

			return false;
		}

		public function get_list_theme_purchase( $token, $page = '' ) {
			$themes = array();
			$url    = 'https://api.envato.com/v3/market/buyer/list-purchases?filter_by=wordpress-themes' . ( $page ? '&page=' . $page : '' );

			$response_themes = wp_remote_get(
				$url,
				array(
					'headers'      => array(
						'Authorization' => 'Bearer ' . $token,
						'User-Agent'    => 'Purchase code verification script',
					),
					'timeout'      => 20,
					'headers_data' => false,
					'sslverify'    => false,
				)
			);
			$response_themes = json_decode( wp_remote_retrieve_body( $response_themes ), true );

			if ( ! is_wp_error( $response_themes ) && isset( $response_themes['results'] ) ) {
				foreach ( (array) $response_themes['results'] as $theme ) {
					$themes[] = array(
						'id'         => isset( $theme['item']['id'] ) ? $theme['item']['id'] : '',
						'name'       => isset( $theme['item']['wordpress_theme_metadata']['theme_name'] ) ? $theme['item']['wordpress_theme_metadata']['theme_name'] : '',
						'author'     => isset( $theme['item']['wordpress_theme_metadata']['author_name'] ) ? $theme['item']['wordpress_theme_metadata']['author_name'] : '',
						'url'        => isset( $theme['item']['url'] ) ? $theme['item']['url'] : '',
						'author_url' => isset( $theme['item']['author_url'] ) ? $theme['item']['author_url'] : '',
					);
				}
			}

			return $themes;
		}
	}
}

new Penci_Require_Active();
