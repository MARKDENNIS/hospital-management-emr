<?php
if ( ! function_exists( 'penci_ajax_search_assets' ) ) {
	add_action( 'wp_enqueue_scripts', 'penci_ajax_search_assets' );
	function penci_ajax_search_assets() {

		if ( ! get_theme_mod( 'penci_ajxs_enable' ) ) {
			return;
		}

		$is_enable_rest = get_theme_mod( 'penci_handle_ajax_with_rest_api' );

		wp_register_script(
			'penci-autocomplete',
			PENCI_SOLEDAD_URL . '/js/jquery.autocomplete.min.js',
			array(),
			PENCI_SOLEDAD_VERSION,
			true
		);

		wp_register_script(
			'penci-ajaxsearch',
			PENCI_SOLEDAD_URL . '/js/ajax-search.js',
			array( 'penci-autocomplete', 'jquery' ),
			PENCI_SOLEDAD_VERSION,
			true
		);

		wp_localize_script( 'penci-ajaxsearch', 'penci_ajsr', array(
			'ajaxUrl'    => $is_enable_rest
				? esc_url( rest_url( 'penci/v1/penci_ajax_search' ) )
				: esc_url( admin_url( 'admin-ajax.php' ) ),
			'minchar'    => absint( get_theme_mod( 'penci_ajxs_character', 2 ) ),
			'maxitems'   => absint( get_theme_mod( 'penci_ajxs_count', get_option( 'posts_per_page' ) ) ),
			'citems'     => (bool) get_theme_mod( 'penci_ajxs_count' ),
			'thumbnail'  => (bool) get_theme_mod( 'penci_ajxs_thumb', true ),
			'date'       => (bool) get_theme_mod( 'penci_ajxs_date', true ),
			'allresults' => esc_html( penci_get_setting( 'penci_trans_allresult' ) ),
			// FIX: nonce scoped to action, not a generic search nonce reused across methods
			'nonce'      => wp_create_nonce( 'penci_ajax_search_nonce' ),
		) );
	}
}

if ( ! function_exists( 'penci_search_form' ) ) {
	function penci_search_form( $args = array() ) {
		$args = wp_parse_args( $args, array(
			'ajax'                   => get_theme_mod( 'penci_ajxs_enable' ),
			'post_type'              => 'post',
			'show_categories'        => false,
			'type'                   => 'form',
			'thumbnail'              => true,
			'price'                  => true,
			'count'                  => get_option( 'posts_per_page' ),
			'icon_type'              => '',
			'search_style'           => '',
			'custom_icon'            => '',
			'el_classes'             => '',
			'innerclass'             => '',
			'innerclass_css'         => 'inner-hbg-search-form',
			'wrapper_custom_classes' => '',
		) );

		// FIX: avoid extract() — it pollutes scope and is a security risk with unvalidated keys
		$ajax                   = (bool) $args['ajax'];
		$post_type              = sanitize_key( $args['post_type'] );
		$show_categories        = (bool) $args['show_categories'];
		$type                   = sanitize_key( $args['type'] );
		$thumbnail              = (bool) $args['thumbnail'];
		$price                  = (bool) $args['price'];
		$count                  = absint( $args['count'] );
		$icon_type              = sanitize_key( $args['icon_type'] );
		$search_style           = sanitize_key( $args['search_style'] );
		$custom_icon            = $args['custom_icon']; // HTML — caller is responsible
		$el_classes             = esc_attr( $args['el_classes'] );
		$innerclass             = (bool) $args['innerclass'];
		$innerclass_css         = esc_attr( $args['innerclass_css'] );
		$wrapper_custom_classes = esc_attr( $args['wrapper_custom_classes'] );

		if ( $ajax ) {
			ob_start();

			$class             = '';
			$btn_classes       = '';
			$data_attrs        = '';
			$wrapper_classes   = '';
			$dropdowns_classes = '';

			if ( $show_categories && $post_type === 'product' ) {
				$class .= ' penci-with-cat has-categories-dropdown';
			}

			if ( $icon_type === 'custom' ) {
				$btn_classes .= ' penci-with-img penci-searchform-custom-icon';
			}

			if ( $search_style ) {
				$class .= ' search-style-' . esc_attr( $search_style );
			}

			$ajax_args = array(
				'thumbnail'     => $thumbnail ? '1' : '0',
				'price'         => $price ? '1' : '0',
				'post_type'     => esc_attr( $post_type ),
				'count'         => $count,
				'sku'           => '1',
				'symbols_count' => 3,
			);

			$class .= ' penci-ajax-search';
			foreach ( $ajax_args as $key => $value ) {
				// FIX: was concatenating raw $data without escaping keys or values
				$data_attrs .= ' data-' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
			}

			$placeholder = esc_attr( penci_get_setting( 'penci_trans_type_and_hit' ) );
			$description = '';

			switch ( $post_type ) {
				case 'product':
					$description = penci_get_setting( 'penci_trans_sepproduct_desc' );
					break;
				case 'portfolio':
					$description = penci_get_setting( 'penci_trans_sepproject_desc' );
					break;
				default:
					$description = penci_get_setting( 'penci_trans_seppost_desc' );
					break;
			}

			if ( $el_classes ) {
				$class .= ' ' . $el_classes;
			}

			if ( $wrapper_custom_classes ) {
				$wrapper_classes .= ' ' . $wrapper_custom_classes;
			}

			if ( $type === 'dropdown' ) {
				$wrapper_classes .= ' penci-dropdown';
			}

			if ( $type === 'full-screen' ) {
				$wrapper_classes .= ' penci-fill';
			} else {
				$dropdowns_classes .= ' penci-dropdown';
			}

			$wrapper_classes   .= ' penci-search-' . esc_attr( $type );
			$dropdowns_classes .= ' penci-search-results';

			?>
			<div class="penci-search-<?php echo esc_attr( $type ); ?> <?php echo esc_attr( $wrapper_classes ); ?>">
				<?php if ( $type === 'full-screen' ) : ?>
					<span class="penci-close-search penci-action-btn penci-style-icon penci-cross-icon"><a></a></span>
				<?php endif; ?>

				<form autocomplete="off" role="search" method="get"
				      class="pc-searchform searchform <?php echo esc_attr( $class ); ?>"
				      action="<?php echo esc_url( home_url( '/' ) ); ?>"
					<?php echo $data_attrs; // already escaped above ?>>

					<?php if ( $innerclass ) : ?>
						<div class="<?php echo esc_attr( $innerclass_css ); ?>">
					<?php endif; ?>

					<input
						type="text"
						class="s search-input"
						placeholder="<?php echo $placeholder; ?>"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						name="s"
						aria-label="<?php echo esc_attr( penci_get_setting( 'penci_trans_search' ) ); ?>"
						title="<?php echo $placeholder; ?>"
					/>

					<?php if ( $icon_type === 'custom' ) {
						echo $custom_icon; // Caller-supplied HTML
					} ?>

					<button type="submit" class="searchsubmit<?php echo esc_attr( $btn_classes ); ?>">
						<span><?php echo esc_html( penci_get_setting( 'penci_trans_search' ) ); ?></span>
					</button>

					<?php if ( $innerclass ) : ?>
						</div>
					<?php endif; ?>

				</form>

				<?php if ( $type === 'full-screen' ) : ?>
					<div class="search-info-text"><span><?php echo esc_html( $description ); ?></span></div>
				<?php endif; ?>

				<div class="search-results-wrapper">
					<div class="penci-dropdown-results penci-scroll<?php echo esc_attr( $dropdowns_classes ); ?>">
						<div class="penci-search-results-wrapper"></div>
					</div>
					<?php if ( $type === 'full-screen' ) : ?>
						<div class="penci-search-loader"></div>
					<?php endif; ?>
				</div>
			</div>
			<?php

			echo apply_filters( 'get_search_form', ob_get_clean() );
			wp_enqueue_script( 'penci-ajaxsearch' );

		} else {
			if ( $args['wrapper_custom_classes'] ) {
				echo '<div class="' . esc_attr( $args['wrapper_custom_classes'] ) . '">';
			}
			?>
			<form role="search" method="get" class="pc-searchform"
			      action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<div class="pc-searchform-inner">
					<input
						type="text"
						class="search-input"
						placeholder="<?php echo esc_attr( penci_get_setting( 'penci_trans_type_and_hit' ) ); ?>"
						name="s"
					/>
					<i class="penciicon-magnifiying-glass"></i>
					<button type="submit" class="searchsubmit penci-ele-btn">
						<?php echo esc_html( penci_get_setting( 'penci_trans_search' ) ); ?>
					</button>
				</div>
			</form>
			<?php
			if ( $args['wrapper_custom_classes'] ) {
				echo '</div>';
			}
		}
	}
}

/**
 * ------------------------------------------------------------------------------------------------
 * Ajax search — admin-ajax handler
 * ------------------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'penci_ajax_suggestions' ) ) {
	function penci_ajax_suggestions() {
		// FIX: was using check_ajax_referer with the old nonce name — kept consistent with new name
		if ( ! check_ajax_referer( 'penci_ajax_search_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'Invalid nonce.' ), 403 );
		}

		// FIX: use wp_send_json_success instead of raw json_encode + die()
		wp_send_json_success( penci_ajax_search_results( $_REQUEST ) );
	}

	add_action( 'wp_ajax_penci_ajax_search',        'penci_ajax_suggestions', 10 );
	add_action( 'wp_ajax_nopriv_penci_ajax_search', 'penci_ajax_suggestions', 10 );
}

/**
 * ------------------------------------------------------------------------------------------------
 * Ajax search — REST API handler
 * ------------------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'penci_register_ajax_search_rest_route' ) ) {
	add_action( 'rest_api_init', 'penci_register_ajax_search_rest_route' );
	function penci_register_ajax_search_rest_route() {
		register_rest_route( 'penci/v1', '/penci_ajax_search', array(
			'methods'             => WP_REST_Server::READABLE, // GET only
			'callback'            => 'penci_rest_ajax_search_handler',
			// FIX: original code had NO permission/nonce check on the REST route at all
			'permission_callback' => function ( WP_REST_Request $request ) {
				return wp_verify_nonce( $request->get_header( 'X-WP-Nonce' ) ?? $request->get_param( 'nonce' ), 'penci_ajax_search_nonce' );
			},
			'args'                => array(
				'query'  => array(
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => function ( $value ) {
						return is_string( $value ) && mb_strlen( $value ) <= 200;
					},
				),
				'number' => array(
					'default'           => 5,
					'sanitize_callback' => 'absint',
					'validate_callback' => function ( $value ) {
						return is_numeric( $value ) && (int) $value <= 50;
					},
				),
				'nonce'  => array( 'sanitize_callback' => 'sanitize_text_field' ),
			),
		) );
	}

	function penci_rest_ajax_search_handler( WP_REST_Request $request ) {
		$results = penci_ajax_search_results( $request->get_params() );
		return rest_ensure_response( $results );
	}
}

/**
 * ------------------------------------------------------------------------------------------------
 * Core search query
 * ------------------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'penci_ajax_search_results' ) ) {
	function penci_ajax_search_results( $requests ) {

		// --- Input sanitization -----------------------------------------------------------------
		$search_query = isset( $requests['query'] )
			? sanitize_text_field( wp_unslash( $requests['query'] ) )
			: '';

		// FIX: clamp number to a safe maximum to prevent DoS via huge result sets
		$number = isset( $requests['number'] )
			? min( absint( $requests['number'] ), 50 )
			: 5;

		if ( $search_query === '' ) {
			return array( 'suggestions' => array(), 'allsearch' => '' );
		}

		// --- Build allowed post types list (cached per request) ---------------------------------
		static $array_include = null;
		if ( $array_include === null ) {
			$post_types = get_post_types(
				array(
					'public'            => true,
					'show_in_nav_menus' => true,
				),
				'names'
			);

			$exclude = array(
				'web-story',
				'e-landing-page',
				'penci-block',
				'penci_builder',
				'archive-template',
				'custom-post-template',
			);

			if ( ! get_theme_mod( 'penci_include_search_page' ) ) {
				$exclude[] = 'page';
			}

			$array_include = array_values( array_diff( $post_types, $exclude ) );
		}

		// --- Query ----------------------------------------------------------------------------------
		$query_args = array(
			'posts_per_page'         => $number,
			'post_status'            => 'publish',
			'post_type'              => $array_include,
			'no_found_rows'          => true,  // FIX: must be boolean true, not int 1
			's'                      => $search_query,
			// PERFORMANCE: fetch only the columns we actually use
			'fields'                 => 'ids',
			// PERFORMANCE: skip unnecessary meta/term queries
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		);

		$results = new WP_Query( apply_filters( 'penci_ajax_search_args', $query_args ) );

		$suggestions        = array();
		$show_format_icons  = (bool) get_theme_mod( 'penci_ajxs_fmat_icon' );
		$title_words        = absint( get_theme_mod( 'penci_ajxs_title_words', 8 ) );
		$no_thumb_url       = PENCI_SOLEDAD_URL . '/images/no-thumb.jpg';

		if ( $results->have_posts() ) {
			// PERFORMANCE: fetch thumbnails in one batch instead of one query per post
			$post_ids      = $results->posts; // 'fields'=>'ids' returns plain array of IDs
			$thumbnail_ids = array();
			foreach ( $post_ids as $pid ) {
				$tid = get_post_thumbnail_id( $pid );
				if ( $tid ) {
					$thumbnail_ids[ $pid ] = $tid;
				}
			}

			// Prime the attachment cache for all thumbnails at once
			if ( ! empty( $thumbnail_ids ) ) {
				_prime_post_caches( array_values( $thumbnail_ids ), false, true );
			}

			foreach ( $post_ids as $pid ) {
				$post        = get_post( $pid );
				$post_format = get_post_format( $pid );

				$post_format_icon = '';
				if ( $show_format_icons ) {
					switch ( $post_format ) {
						case 'video':
							$post_format_icon = penci_icon_by_ver( 'fas fa-play', '' );
							break;
						case 'audio':
							$post_format_icon = penci_icon_by_ver( 'fas fa-music', '' );
							break;
						case 'link':
							$post_format_icon = penci_icon_by_ver( 'fas fa-link', '' );
							break;
						case 'quote':
							$post_format_icon = penci_icon_by_ver( 'fas fa-quote-left', '' );
							break;
						case 'gallery':
							$post_format_icon = penci_icon_by_ver( 'far fa-image', '' );
							break;
					}
				}

				$has_thumb = isset( $thumbnail_ids[ $pid ] );
				$thumb_img = $has_thumb
					? get_the_post_thumbnail_url( $pid, 'thumbnail' )
					: $no_thumb_url;

				$title = html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ) );

				$suggestions[] = array(
					'value'     => html_entity_decode( wp_trim_words( $title, $title_words ) ),
					'title'     => $title,
					'permalink' => get_permalink( $pid ),
					'date'      => get_the_date( '', $pid ),
					'thumbnail' => '<a ' . penci_layout_bg( $thumb_img ) . ' class="penci-image-holder ' . penci_layout_bg_class() . '">'
					               . penci_layout_img( $thumb_img )
					               . $post_format_icon
					               . '</a>',
				);
			}

			wp_reset_postdata();
		} else {
			$suggestions[] = array(
				'value'    => esc_html( penci_get_setting( 'penci_trans_npostfound' ) ),
				'no_found' => true,
				'permalink' => '',
			);
		}

		return array(
			'suggestions' => $suggestions,
			// FIX: was using unsanitized $requests['query'] directly in get_search_link()
			'allsearch'   => esc_url( get_search_link( $search_query ) ),
		);
	}
}